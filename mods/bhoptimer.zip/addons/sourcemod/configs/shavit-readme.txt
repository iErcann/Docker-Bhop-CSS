shavit-advertisements.cfg is the file used to determine how shavit-misc posts advertisements to the server.
shavit-chat.cfg is the configuration file for chat titles, colors and all this kind of stuff.
shavit-messages.cfg is the configuration file for chat colors/prefixes etc.
shavit-prefix.txt is the configuration file for the plugin's mysql prefix. do not touch unless you know what you are doing!
shavit-replay.cfg is the configuration file used for the replay bot's name styling.
shavit-sounds.cfg is the configuration file for timer sounds.
shavit-styles.cfg is used to configure custom style settings for the server.
shavit-zones.cfg is where you can choose your own zone sprites. comment the CS:S lines and uncomment the CS:GO lines if you need.